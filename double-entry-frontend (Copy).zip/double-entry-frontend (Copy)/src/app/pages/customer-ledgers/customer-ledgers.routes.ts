import { Routes } from '@angular/router';
import { CustomerLedgers } from './customer-ledgers';

export const CustomerLedgersRoutes: Routes = [
  { path: '', component: CustomerLedgers }
];
