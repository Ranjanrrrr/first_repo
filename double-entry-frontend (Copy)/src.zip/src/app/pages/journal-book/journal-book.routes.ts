import { Routes } from '@angular/router';
import { JournalBookComponent } from './journal-book';

export const JournalBookRoutes: Routes = [
  { path: '', component: JournalBookComponent }
];
