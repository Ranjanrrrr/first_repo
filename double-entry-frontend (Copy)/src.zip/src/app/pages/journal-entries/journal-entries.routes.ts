import { Routes } from '@angular/router';
import { JournalEntryComponent } from './journal-entries';

export const JournalEntriesRoutes: Routes = [
  { path: '', component: JournalEntryComponent }
];
