import { Routes } from '@angular/router';
import { TrialBalanceComponent } from './trial-balance';

export const TrialBalanceRoutes: Routes = [
  { path: '', component: TrialBalanceComponent }
];
