import { Routes } from '@angular/router';
import { Accounts } from './accounts';

export const AccountsRoutes: Routes = [
  {
    path: '',
    component: Accounts
  }
];
