import { Routes } from '@angular/router';
import { Report } from './report';

export const ReportRoutes: Routes = [
  { path: '', component: Report }
];
