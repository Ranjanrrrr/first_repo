import { Routes } from '@angular/router';
import { SupplierLedgers } from './supplier-ledgers';

export const SupplierLedgersRoutes: Routes = [
  { path: '', component: SupplierLedgers }
];
